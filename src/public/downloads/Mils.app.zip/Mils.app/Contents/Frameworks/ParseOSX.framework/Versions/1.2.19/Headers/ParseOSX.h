//
//  ParseOSX.h
//  Copyright (c) 2013 Parse Inc. All rights reserved.
//

#import "Parse.h"